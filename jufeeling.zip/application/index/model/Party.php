<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/9/10
 * Time: 18:55
 */

namespace app\index\model;


use think\Model;

class Party extends Model
{

}