<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/6/4
 * Time: 16:39
 */

namespace app\lib\enum;


class ExpEnum
{
    const Comment = 10;

    const Dynamic = 20;

}