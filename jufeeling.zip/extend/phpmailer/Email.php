<?php
/**
 * 发送邮件类库
 */
namespace phpmailer;
use think\Exception;

class Email {
    /**
     * @param $to
     * @param $title
     * @param $content
     * @return bool
     */
    public  static function send($to, $title, $content) {
        date_default_timezone_set('PRC');//set time
        if(empty($to)) {
            return false;
        }
        try {
            $mail = new PHPMailer;
            $mail->isSMTP();
            $mail->Debugoutput = 'html';
            $mail->Host = config('email.host');
            $mail->Port = config('email.port');
            $mail->SMTPAuth = true;
            $mail->Username = config('email.username');
            $mail->Password = config('email.password');
            $mail->setFrom(config('email.username'), 'locust');
            $mail->addAddress($to);
            $mail->Subject = $title;
            $mail->msgHTML($content);
            if (!$mail->send()) {
                return false;
            } else {
                return true;
            }
        }catch(phpmailerException $e) {
            return false;
        }
    }
}