<?php /*a:4:{s:67:"C:\wamp64\www\bbs_coolcoder\application\Index\view\Index\Index.html";i:1527228501;s:69:"C:\wamp64\www\bbs_coolcoder\application\Index\view\template\base.html";i:1527237338;s:69:"C:\wamp64\www\bbs_coolcoder\application\Index\view\public\header.html";i:1527238668;s:69:"C:\wamp64\www\bbs_coolcoder\application\Index\view\public\footer.html";i:1527048504;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>敲客大学生编程社区</title>
    <link rel="stylesheet" href="/static/css/style.css">
    <script src="/static/js/jquery-3.3.1.min.js"></script>
    <!--拓展样式表区域-->
    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.2.6/css/swiper.min.css">
<link rel="stylesheet" href="/static/css/home.css">

</head>
<body>
<!--头部-->
<header class="header">
    <a class="logo" href="/"></a>
    <div class="user-box">
        <?php if(empty(app('session')->get('user')) || ((app('session')->get('user') instanceof \think\Collection || app('session')->get('user') instanceof \think\Paginator ) && app('session')->get('user')->isEmpty())): ?>
        <div class="login-box">
            <a href="/login">登录</a>
        </div>
        <?php else: ?>
        <div class="user-info">
            <img class="user-avatar" src="<?php echo htmlentities((app('session')->get('user.avatar') ?: '/static/images/normal.jpg')); ?>" alt="">
            <i class="icon-down-arrow"></i>
            <div class="user-info-content">
                <a class="info-item" href="/selfcenter"><?php echo htmlentities((app('session')->get('user.nickname') ?: '默认名称')); ?></a>
                <span id="outLoginBtn" class="info-item">退出</span>
                <i class="box-icon-top-arrow"></i>
            </div>
        </div>
        <?php endif; ?>
    </div>
</header>

<!--主体-->

<div class="body">
    <div class="container-box">
        <div class="home-top">
            <div class="banner">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img src="/static/images/banner1.jpg" alt="">
                        </div>
                        <div class="swiper-slide">
                            <img src="/static/images/banner1.jpg" alt="">
                        </div>
                        <div class="swiper-slide">
                            <img src="/static/images/banner1.jpg" alt="">
                        </div>
                        <!-- 如果需要分页器 -->
                        <div class="swiper-pagination"></div>
                        <!-- 如果需要导航按钮 -->
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-button-next"></div>
                    </div>
                </div>
            </div>
            <div class="notice" style="">
                <div class="notice-content">
                    <a class="title" href="">官方公告：2018敲客·西南民族大学大创立项结果</a>
                    <span class="time">2018-05-21</span>
                </div>
                <div class="more">
                    <a href="">更多 >> </a>
                </div>
            </div>
        </div>

        <div class="main-box">
            <div class="post-hd">
                <h2 class="title">全部帖子</h2>
                <div class="post-hd-right">
                    <button class="">发布新帖</button>
                    <div class="more">
                        <a href="">查看所有 >> </a>
                    </div>
                </div>
            </div>
            <div class="post-bd">
                <div class="post-item">
                    <a class="post-title" href="">小游戏排行榜“唯一标识”到底是不是key</a>
                    <div class="post-info">
                        <div class="left-info">
                            <a class="post-author left-info-item">拉灰Larry</a>
                            <span class="post-time left-info-item">星期四 13:51</span>
                        </div>
                        <div class="right-info">
                            <span class="post-view">621</span>
                            <span class="post-comment">21</span>
                        </div>
                    </div>
                </div>

                <div class="post-item">
                    <a class="post-title" href="">小游戏排行榜“唯一标识”到底是不是key</a>
                    <div class="post-info">
                        <div class="left-info">
                            <a class="post-author left-info-item">拉灰Larry</a>
                            <span class="post-time left-info-item">星期四 13:51</span>
                        </div>
                        <div class="right-info">
                            <span class="post-view">621</span>
                            <span class="post-comment">21</span>
                        </div>
                    </div>
                </div>

                <div class="post-item">
                    <a class="post-title" href="">小游戏排行榜“唯一标识”到底是不是key</a>
                    <div class="post-info">
                        <div class="left-info">
                            <a class="post-author left-info-item">拉灰Larry</a>
                            <span class="post-time left-info-item">星期四 13:51</span>
                        </div>
                        <div class="right-info">
                            <span class="post-view">621</span>
                            <span class="post-comment">21</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="hot-user">
            <h2>社区活跃用户</h2>
            <div class="hot-user-box">
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
                <div class="hot-user-item">
                    <a href=""><img src="/static/images/normal.jpg" alt=""></a>
                </div>
            </div>
        </div>
    </div>
</div>

<!--底部-->
<footer class="footer">
    <ul>
        <li class="links_item">
            <a href="http://www.coolcoder.cn" target="_blank">敲客官网</a>
        </li>
        <li class="links_item">西南民族大学敲客团队</li>
        <li class="links_item">Copyright © 2016-2018 敲客CoolCoder. All Rights Reserved.</li>
    </ul>
</footer>

<!--拓展脚本区域-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.2.6/js/swiper.min.js"></script>
<script>
    var mySwiper = new Swiper ('.swiper-container', {
        autoplay: true,
        loop: true,

        // 如果需要分页器
        pagination: {
            el: '.swiper-pagination',
        },

        // 如果需要前进后退按钮
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
    mySwiper.el.onmouseover = function(){
        mySwiper.autoplay.stop();
    }
</script>

<script src="/static/js/user.js"></script>
</body>
</html>