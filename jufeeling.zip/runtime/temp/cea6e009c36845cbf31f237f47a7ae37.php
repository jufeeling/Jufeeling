<?php /*a:4:{s:66:"C:\wamp64\www\bbs_coolcoder\application\Index\view\user\login.html";i:1527237338;s:69:"C:\wamp64\www\bbs_coolcoder\application\Index\view\template\base.html";i:1527237338;s:69:"C:\wamp64\www\bbs_coolcoder\application\Index\view\public\header.html";i:1527238668;s:69:"C:\wamp64\www\bbs_coolcoder\application\Index\view\public\footer.html";i:1527048504;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>敲客大学生编程社区</title>
    <link rel="stylesheet" href="/static/css/style.css">
    <script src="/static/js/jquery-3.3.1.min.js"></script>
    <!--拓展样式表区域-->
    
<link rel="stylesheet" href="/static/css/login.css">

</head>
<body>
<!--头部-->
<header class="header">
    <a class="logo" href="/"></a>
    <div class="user-box">
        <?php if(empty(app('session')->get('user')) || ((app('session')->get('user') instanceof \think\Collection || app('session')->get('user') instanceof \think\Paginator ) && app('session')->get('user')->isEmpty())): ?>
        <div class="login-box">
            <a href="/login">登录</a>
        </div>
        <?php else: ?>
        <div class="user-info">
            <img class="user-avatar" src="<?php echo htmlentities((app('session')->get('user.avatar') ?: '/static/images/normal.jpg')); ?>" alt="">
            <i class="icon-down-arrow"></i>
            <div class="user-info-content">
                <a class="info-item" href="/selfcenter"><?php echo htmlentities((app('session')->get('user.nickname') ?: '默认名称')); ?></a>
                <span id="outLoginBtn" class="info-item">退出</span>
                <i class="box-icon-top-arrow"></i>
            </div>
        </div>
        <?php endif; ?>
    </div>
</header>

<!--主体-->

<div class="body">
    <div class="container-box">
        <div class="main-box">
            <div class="login-box">
                <div class="login-title">
                    <img class="login-logo" src="/static/images/coolcoder.svg" alt="">
                    <p class="login-slogan">这是一群有趣的程序员</p>
                </div>
                <div class="login-body">
                    <div class="login-item">
                        <input class="login-input" id="username" name="username" type="text" placeholder="手机号或邮箱">
                    </div>
                    <div class="phone-info"></div>
                    <div class="login-item">
                        <input class="login-input" id="password" name="password" type="password" placeholder="密码">
                    </div>
                    <div class="password-info"></div>
                    <div class="login-options">
                        <span class="login-option">没有账号？<a href="/register">注册</a></span>
                        <a href="">忘记密码</a>
                    </div>
                    <button id="loginBtn" class="login-btn" type="button">登陆</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!--底部-->
<footer class="footer">
    <ul>
        <li class="links_item">
            <a href="http://www.coolcoder.cn" target="_blank">敲客官网</a>
        </li>
        <li class="links_item">西南民族大学敲客团队</li>
        <li class="links_item">Copyright © 2016-2018 敲客CoolCoder. All Rights Reserved.</li>
    </ul>
</footer>

<!--拓展脚本区域-->


<script src="/static/js/user.js"></script>
</body>
</html>