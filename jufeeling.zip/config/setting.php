<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/7/6
 * Time: 20:35
 */


return [
    'img_prefix' => 'http://z.cn/images',
    'token_expire_in' => 7200
];