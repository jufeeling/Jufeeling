<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/7/30
 * Time: 11:07
 */

/**
 * 百度地图配置
 */
return [
    'ak'            => 'uLjYa1QuWEOiRlPGjpqo4rTSzM1vYh62',
    'baidu_map_url' => 'http://api.map.baidu.com/geocoder/v2/',
];