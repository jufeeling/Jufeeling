<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/8/9
 * Time: 16:11
 */
return [
    'host' => 'smtp.126.com',
    'port' => 25,
    'username' => 'Colocust@126.com',
    'password' => 'wu970429'
];