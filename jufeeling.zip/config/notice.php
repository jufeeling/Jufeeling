<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/5/24
 * Time: 16:37
 */

return [
    'user_no_info' => array
    (
        'title' => '请继续完善你的信息',
        'content' => '敲客是一个有爱的社区，请完善你的信息和大家交个朋友吧',
        'button' =>[
            'content' => '立即完善',
            'url' => '/profile'
        ],
    )
];